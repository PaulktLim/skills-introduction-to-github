<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        ' ── Controls ──
        Me.grpConnection = New System.Windows.Forms.GroupBox()
        Me.lblBrand = New System.Windows.Forms.Label()
        Me.cmbBrand = New System.Windows.Forms.ComboBox()
        Me.lblPort = New System.Windows.Forms.Label()
        Me.cmbPort = New System.Windows.Forms.ComboBox()
        Me.lblBaud = New System.Windows.Forms.Label()
        Me.cmbBaud = New System.Windows.Forms.ComboBox()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()

        Me.grpMeasurement = New System.Windows.Forms.GroupBox()
        Me.lblHzL = New System.Windows.Forms.Label()
        Me.txtHz = New System.Windows.Forms.TextBox()
        Me.lblVL = New System.Windows.Forms.Label()
        Me.txtV = New System.Windows.Forms.TextBox()
        Me.lblDistL = New System.Windows.Forms.Label()
        Me.txtDist = New System.Windows.Forms.TextBox()
        Me.lblTsL = New System.Windows.Forms.Label()
        Me.txtTimestamp = New System.Windows.Forms.TextBox()

        Me.grpControl = New System.Windows.Forms.GroupBox()
        Me.btnMeasure = New System.Windows.Forms.Button()
        Me.lblInterval = New System.Windows.Forms.Label()
        Me.nudInterval = New System.Windows.Forms.NumericUpDown()
        Me.btnMonitor = New System.Windows.Forms.Button()

        Me.grpLog = New System.Windows.Forms.GroupBox()
        Me.txtLog = New System.Windows.Forms.TextBox()
        Me.btnClearLog = New System.Windows.Forms.Button()

        Me.grpConnection.SuspendLayout()
        Me.grpMeasurement.SuspendLayout()
        Me.grpControl.SuspendLayout()
        Me.grpLog.SuspendLayout()
        CType(Me.nudInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()

        ' ── grpConnection ──
        Me.grpConnection.Location = New System.Drawing.Point(12, 12)
        Me.grpConnection.Size = New System.Drawing.Size(460, 105)
        Me.grpConnection.Text = "Connection"
        Me.grpConnection.Controls.AddRange(New System.Windows.Forms.Control() {
            Me.lblBrand, Me.cmbBrand, Me.lblPort, Me.cmbPort,
            Me.lblBaud, Me.cmbBaud, Me.btnConnect, Me.lblStatus})

        Me.lblBrand.Text = "Brand:" : Me.lblBrand.Location = New System.Drawing.Point(10, 24) : Me.lblBrand.AutoSize = True
        Me.cmbBrand.Location = New System.Drawing.Point(60, 20) : Me.cmbBrand.Size = New System.Drawing.Size(90, 21) : Me.cmbBrand.DropDownStyle = ComboBoxStyle.DropDownList

        Me.lblPort.Text = "Port:" : Me.lblPort.Location = New System.Drawing.Point(165, 24) : Me.lblPort.AutoSize = True
        Me.cmbPort.Location = New System.Drawing.Point(200, 20) : Me.cmbPort.Size = New System.Drawing.Size(90, 21) : Me.cmbPort.DropDownStyle = ComboBoxStyle.DropDownList

        Me.lblBaud.Text = "Baud:" : Me.lblBaud.Location = New System.Drawing.Point(305, 24) : Me.lblBaud.AutoSize = True
        Me.cmbBaud.Location = New System.Drawing.Point(340, 20) : Me.cmbBaud.Size = New System.Drawing.Size(80, 21) : Me.cmbBaud.DropDownStyle = ComboBoxStyle.DropDownList

        Me.btnConnect.Text = "Connect"
        Me.btnConnect.Location = New System.Drawing.Point(60, 52)
        Me.btnConnect.Size = New System.Drawing.Size(90, 28)

        Me.lblStatus.Text = "○ Disconnected"
        Me.lblStatus.ForeColor = System.Drawing.Color.Red
        Me.lblStatus.Location = New System.Drawing.Point(175, 58)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold)

        ' ── grpMeasurement ──
        Me.grpMeasurement.Location = New System.Drawing.Point(12, 125)
        Me.grpMeasurement.Size = New System.Drawing.Size(460, 130)
        Me.grpMeasurement.Text = "Latest Measurement"
        Me.grpMeasurement.Controls.AddRange(New System.Windows.Forms.Control() {
            Me.lblHzL, Me.txtHz, Me.lblVL, Me.txtV,
            Me.lblDistL, Me.txtDist, Me.lblTsL, Me.txtTimestamp})

        Me.lblHzL.Text = "Hz Angle (°):" : Me.lblHzL.Location = New System.Drawing.Point(10, 28) : Me.lblHzL.AutoSize = True
        Me.txtHz.Location = New System.Drawing.Point(110, 25) : Me.txtHz.Size = New System.Drawing.Size(140, 20) : Me.txtHz.ReadOnly = True : Me.txtHz.BackColor = System.Drawing.Color.LightYellow

        Me.lblVL.Text = "V Angle (°):" : Me.lblVL.Location = New System.Drawing.Point(10, 58) : Me.lblVL.AutoSize = True
        Me.txtV.Location = New System.Drawing.Point(110, 55) : Me.txtV.Size = New System.Drawing.Size(140, 20) : Me.txtV.ReadOnly = True : Me.txtV.BackColor = System.Drawing.Color.LightYellow

        Me.lblDistL.Text = "Slope Dist (m):" : Me.lblDistL.Location = New System.Drawing.Point(10, 88) : Me.lblDistL.AutoSize = True
        Me.txtDist.Location = New System.Drawing.Point(110, 85) : Me.txtDist.Size = New System.Drawing.Size(140, 20) : Me.txtDist.ReadOnly = True : Me.txtDist.BackColor = System.Drawing.Color.LightYellow

        Me.lblTsL.Text = "Timestamp:" : Me.lblTsL.Location = New System.Drawing.Point(275, 28) : Me.lblTsL.AutoSize = True
        Me.txtTimestamp.Location = New System.Drawing.Point(340, 25) : Me.txtTimestamp.Size = New System.Drawing.Size(105, 20) : Me.txtTimestamp.ReadOnly = True : Me.txtTimestamp.BackColor = System.Drawing.Color.LightYellow

        ' ── grpControl ──
        Me.grpControl.Location = New System.Drawing.Point(12, 263)
        Me.grpControl.Size = New System.Drawing.Size(460, 65)
        Me.grpControl.Text = "Control"
        Me.grpControl.Controls.AddRange(New System.Windows.Forms.Control() {
            Me.btnMeasure, Me.lblInterval, Me.nudInterval, Me.btnMonitor})

        Me.btnMeasure.Text = "Single Measure"
        Me.btnMeasure.Location = New System.Drawing.Point(15, 25)
        Me.btnMeasure.Size = New System.Drawing.Size(110, 28)
        Me.btnMeasure.Enabled = False

        Me.lblInterval.Text = "Interval (s):" : Me.lblInterval.Location = New System.Drawing.Point(145, 30) : Me.lblInterval.AutoSize = True
        Me.nudInterval.Location = New System.Drawing.Point(225, 27) : Me.nudInterval.Size = New System.Drawing.Size(55, 20)
        Me.nudInterval.Minimum = 1 : Me.nudInterval.Maximum = 3600 : Me.nudInterval.Value = 5

        Me.btnMonitor.Text = "Start Monitor"
        Me.btnMonitor.Location = New System.Drawing.Point(295, 25)
        Me.btnMonitor.Size = New System.Drawing.Size(110, 28)
        Me.btnMonitor.Enabled = False

        ' ── grpLog ──
        Me.grpLog.Location = New System.Drawing.Point(12, 336)
        Me.grpLog.Size = New System.Drawing.Size(760, 260)
        Me.grpLog.Text = "Measurement Log"
        Me.grpLog.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtLog, Me.btnClearLog})

        Me.txtLog.Location = New System.Drawing.Point(8, 20)
        Me.txtLog.Size = New System.Drawing.Size(740, 200)
        Me.txtLog.Multiline = True : Me.txtLog.ReadOnly = True : Me.txtLog.ScrollBars = ScrollBars.Vertical
        Me.txtLog.Font = New System.Drawing.Font("Courier New", 8.5)
        Me.txtLog.BackColor = System.Drawing.Color.Black : Me.txtLog.ForeColor = System.Drawing.Color.LimeGreen

        Me.btnClearLog.Text = "Clear Log"
        Me.btnClearLog.Location = New System.Drawing.Point(8, 228)
        Me.btnClearLog.Size = New System.Drawing.Size(90, 25)

        ' ── Form1 ──
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(790, 610)
        Me.Text = "GiMoS — Geotechnical Survey Monitoring System"
        Me.Controls.AddRange(New System.Windows.Forms.Control() {
            Me.grpConnection, Me.grpMeasurement, Me.grpControl, Me.grpLog})
        Me.MinimumSize = New System.Drawing.Size(806, 650)

        Me.grpConnection.ResumeLayout(False)
        Me.grpMeasurement.ResumeLayout(False)
        Me.grpControl.ResumeLayout(False)
        Me.grpLog.ResumeLayout(False)
        CType(Me.nudInterval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub

    ' ── Control declarations ──
    Friend WithEvents grpConnection As GroupBox
    Friend WithEvents lblBrand As Label
    Friend WithEvents cmbBrand As ComboBox
    Friend WithEvents lblPort As Label
    Friend WithEvents cmbPort As ComboBox
    Friend WithEvents lblBaud As Label
    Friend WithEvents cmbBaud As ComboBox
    Friend WithEvents btnConnect As Button
    Friend WithEvents lblStatus As Label

    Friend WithEvents grpMeasurement As GroupBox
    Friend WithEvents lblHzL As Label
    Friend WithEvents txtHz As TextBox
    Friend WithEvents lblVL As Label
    Friend WithEvents txtV As TextBox
    Friend WithEvents lblDistL As Label
    Friend WithEvents txtDist As TextBox
    Friend WithEvents lblTsL As Label
    Friend WithEvents txtTimestamp As TextBox

    Friend WithEvents grpControl As GroupBox
    Friend WithEvents btnMeasure As Button
    Friend WithEvents lblInterval As Label
    Friend WithEvents nudInterval As NumericUpDown
    Friend WithEvents btnMonitor As Button

    Friend WithEvents grpLog As GroupBox
    Friend WithEvents txtLog As TextBox
    Friend WithEvents btnClearLog As Button
End Class
