Imports GiMoSLib.Interfaces
Imports GiMoSLib.Core
Imports GiMoSLib.Models

Public Class Form1

    Private ts As ITotalStation
    Private isConnected As Boolean = False
    Private monitorTimer As New System.Windows.Forms.Timer()
    Private measureCount As Integer = 0

    ' ─────────────────────────────────────────────────────────
    '  FORM LOAD
    ' ─────────────────────────────────────────────────────────
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Populate brand combo
        cmbBrand.Items.Clear()
        cmbBrand.Items.Add("Leica")
        cmbBrand.Items.Add("Sokkia")
        cmbBrand.Items.Add("Trimble")
        cmbBrand.Items.Add("Topcon")
        cmbBrand.SelectedIndex = 0

        ' Populate COM ports
        cmbPort.Items.Clear()
        cmbPort.Items.Add("Simulator")
        For Each port As String In IO.Ports.SerialPort.GetPortNames()
            cmbPort.Items.Add(port)
        Next
        If cmbPort.Items.Count > 0 Then cmbPort.SelectedIndex = 0

        ' Populate baud rates
        cmbBaud.Items.AddRange({"1200", "2400", "4800", "9600", "19200", "38400"})
        cmbBaud.SelectedItem = "9600"

        ' Monitoring timer
        AddHandler monitorTimer.Tick, AddressOf MonitorTimer_Tick
        monitorTimer.Interval = 2000   ' every 2 seconds

        UpdateUI()
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  CONNECT / DISCONNECT
    ' ─────────────────────────────────────────────────────────
    Private Sub btnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        If isConnected Then
            ' --- DISCONNECT ---
            monitorTimer.Stop()
            ts.Disconnect()
            isConnected = False
            AppendLog("Disconnected.")
        Else
            ' --- CONNECT ---
            Dim brand As String = cmbBrand.SelectedItem?.ToString()
            Dim port As String = cmbPort.SelectedItem?.ToString()
            Dim baud As Integer = CInt(cmbBaud.SelectedItem?.ToString())
            Dim simulate As Boolean = (port = "Simulator")

            Try
                ts = TotalStationFactory.Create(brand, simulate)
                Dim ok As Boolean = ts.Connect(If(simulate, "SIM", port), baud)
                If ok Then
                    isConnected = True
                    AppendLog($"Connected to {brand} {If(simulate, "(Simulator)", "on " & port)} @ {baud} baud.")
                Else
                    AppendLog("Connection failed.")
                End If
            Catch ex As Exception
                AppendLog("Error: " & ex.Message)
            End Try
        End If
        UpdateUI()
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  SINGLE MEASURE
    ' ─────────────────────────────────────────────────────────
    Private Sub btnMeasure_Click(sender As Object, e As EventArgs) Handles btnMeasure.Click
        TakeMeasurement()
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  START / STOP CONTINUOUS MONITORING
    ' ─────────────────────────────────────────────────────────
    Private Sub btnMonitor_Click(sender As Object, e As EventArgs) Handles btnMonitor.Click
        If monitorTimer.Enabled Then
            monitorTimer.Stop()
            AppendLog("Monitoring stopped.")
        Else
            monitorTimer.Interval = CInt(nudInterval.Value) * 1000
            monitorTimer.Start()
            AppendLog($"Monitoring started — every {nudInterval.Value}s.")
        End If
        UpdateUI()
    End Sub

    Private Sub MonitorTimer_Tick(sender As Object, e As EventArgs)
        TakeMeasurement()
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  CORE MEASUREMENT
    ' ─────────────────────────────────────────────────────────
    Private Sub TakeMeasurement()
        If ts Is Nothing OrElse Not isConnected Then
            AppendLog("Not connected.")
            Return
        End If

        Try
            Dim result As MeasurementResult = ts.Measure()
            measureCount += 1

            ' Update display fields
            txtHz.Text = result.Hz.ToString("F6") & "°"
            txtV.Text = result.V.ToString("F6") & "°"
            txtDist.Text = result.SlopeDistance.ToString("F4") & " m"
            txtTimestamp.Text = result.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")

            ' Append to log
            AppendLog($"[{measureCount,4}] Hz={result.Hz:F4}°  V={result.V:F4}°  SD={result.SlopeDistance:F4}m  @{result.Timestamp:HH:mm:ss}")

        Catch ex As Exception
            AppendLog("Measurement error: " & ex.Message)
            monitorTimer.Stop()
            UpdateUI()
        End Try
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  CLEAR LOG
    ' ─────────────────────────────────────────────────────────
    Private Sub btnClearLog_Click(sender As Object, e As EventArgs) Handles btnClearLog.Click
        txtLog.Clear()
        measureCount = 0
    End Sub

    ' ─────────────────────────────────────────────────────────
    '  HELPERS
    ' ─────────────────────────────────────────────────────────
    Private Sub AppendLog(msg As String)
        If txtLog.InvokeRequired Then
            txtLog.Invoke(Sub() AppendLog(msg))
            Return
        End If
        txtLog.AppendText(msg & Environment.NewLine)
        txtLog.ScrollToCaret()
    End Sub

    Private Sub UpdateUI()
        btnConnect.Text = If(isConnected, "Disconnect", "Connect")
        btnMeasure.Enabled = isConnected
        btnMonitor.Enabled = isConnected
        btnMonitor.Text = If(monitorTimer.Enabled, "Stop Monitor", "Start Monitor")
        cmbBrand.Enabled = Not isConnected
        cmbPort.Enabled = Not isConnected
        cmbBaud.Enabled = Not isConnected
        lblStatus.Text = If(isConnected,
            $"● Connected — {cmbBrand.SelectedItem} {cmbPort.SelectedItem}",
            "○ Disconnected")
        lblStatus.ForeColor = If(isConnected, Drawing.Color.Green, Drawing.Color.Red)
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        monitorTimer.Stop()
        If isConnected AndAlso ts IsNot Nothing Then ts.Disconnect()
    End Sub

End Class
