using System;

namespace GiMoSLib.Models
{
    /// <summary>
    /// A single total-station measurement epoch.
    /// </summary>
    public class MeasurementResult
    {
        /// <summary>Horizontal circle reading in decimal degrees.</summary>
        public double Hz { get; set; }

        /// <summary>Vertical circle reading in decimal degrees.</summary>
        public double V { get; set; }

        /// <summary>Slope distance in metres.</summary>
        public double SlopeDistance { get; set; }

        /// <summary>UTC timestamp of the measurement.</summary>
        public DateTime Timestamp { get; set; }

        /// <summary>Instrument brand that produced this reading.</summary>
        public string Brand { get; set; }

        /// <summary>True when produced by the software simulator, not real hardware.</summary>
        public bool IsSimulated { get; set; }
    }
}
