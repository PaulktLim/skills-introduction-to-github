using System.IO.Ports;

namespace GiMoSLib.Core
{
    public abstract class TotalStationBase
    {
        protected SerialPort serial;

        protected bool Open(string port, int baudRate)
        {
            serial = new SerialPort(port, baudRate);
            serial.ReadTimeout  = 5000;
            serial.WriteTimeout = 5000;
            serial.Open();
            return true;
        }

        protected void Close()
        {
            if (serial != null && serial.IsOpen)
                serial.Close();
        }
    }
}
