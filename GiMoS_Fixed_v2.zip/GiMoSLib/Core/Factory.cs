using GiMoSLib.Interfaces;
using GiMoSLib.Drivers.Leica;
using GiMoSLib.Drivers.Sokkia;
using GiMoSLib.Drivers.Trimble;
using GiMoSLib.Drivers.Topcon;
using System;

namespace GiMoSLib.Core
{
    public static class TotalStationFactory
    {
        /// <summary>
        /// Creates a driver. Pass simulate=true to get a hardware-free simulator.
        /// </summary>
        public static ITotalStation Create(string brand, bool simulate = false)
        {
            if (simulate)
                return new SimulatedTS(brand);   // SimulatedTS is in GiMoSLib.Drivers.Leica namespace

            switch (brand)
            {
                case "Leica":   return new LeicaTS();
                case "Sokkia":  return new SokkiaTS();
                case "Trimble": return new TrimbleTS();
                case "Topcon":  return new TopconTS();
                default:
                    throw new NotSupportedException($"Brand '{brand}' is not supported.");
            }
        }
    }
}
