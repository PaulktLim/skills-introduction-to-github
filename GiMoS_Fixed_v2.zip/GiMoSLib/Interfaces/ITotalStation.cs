using GiMoSLib.Models;

namespace GiMoSLib.Interfaces
{
    public interface ITotalStation
    {
        bool Connect(string port, int baudRate);
        MeasurementResult Measure();
        void Disconnect();
    }
}
