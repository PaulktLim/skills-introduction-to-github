// Intentionally empty.
// The canonical ITotalStation interface is defined in ITotalStation.cs (GiMoSLib.Interfaces).
