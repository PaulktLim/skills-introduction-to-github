using GiMoSLib.Interfaces;
using GiMoSLib.Models;
using GiMoSLib.Core;
using System;

namespace GiMoSLib.Drivers.Topcon
{
    /// <summary>Topcon total station driver (GTS-7 protocol).</summary>
    public class TopconTS : TotalStationBase, ITotalStation
    {
        public bool Connect(string port, int baudRate) => Open(port, baudRate);

        public MeasurementResult Measure()
        {
            serial.WriteLine("MEAS");
            string response = serial.ReadLine();
            return Parse(response);
        }

        public void Disconnect() => Close();

        private MeasurementResult Parse(string res)
        {
            var parts = res.Split(',');
            return new MeasurementResult
            {
                Hz            = double.Parse(parts[0]),
                V             = double.Parse(parts[1]),
                SlopeDistance = double.Parse(parts[2]),
                Timestamp     = DateTime.Now,
                Brand         = "Topcon"
            };
        }
    }
}
