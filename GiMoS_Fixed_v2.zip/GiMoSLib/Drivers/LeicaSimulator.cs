using GiMoSLib.Interfaces;
using GiMoSLib.Models;
using System;

namespace GiMoSLib.Drivers.Leica
{
    /// <summary>
    /// Hardware-free simulator. Produces a realistic random-walk drift so the UI
    /// and logging pipeline can be tested without a physical instrument.
    /// </summary>
    public class SimulatedTS : ITotalStation
    {
        private readonly string _brand;
        private readonly Random _rnd = new Random();

        private double _hz = 45.0;
        private double _v  = 90.0;
        private double _sd = 25.0;

        public SimulatedTS(string brand) { _brand = brand; }

        public bool Connect(string port, int baudRate) => true;

        public MeasurementResult Measure()
        {
            _hz = Wrap360(_hz + (_rnd.NextDouble() - 0.5) * 0.005);
            _v  = Clamp(_v  + (_rnd.NextDouble() - 0.5) * 0.003, 1, 179);
            _sd = Math.Max(1, _sd + (_rnd.NextDouble() - 0.5) * 0.002);

            return new MeasurementResult
            {
                Hz            = Math.Round(_hz, 6),
                V             = Math.Round(_v,  6),
                SlopeDistance = Math.Round(_sd, 4),
                Timestamp     = DateTime.Now,
                Brand         = _brand,
                IsSimulated   = true
            };
        }

        public void Disconnect() { }

        private static double Wrap360(double d) => ((d % 360) + 360) % 360;
        private static double Clamp(double v, double lo, double hi) => Math.Max(lo, Math.Min(hi, v));
    }
}
