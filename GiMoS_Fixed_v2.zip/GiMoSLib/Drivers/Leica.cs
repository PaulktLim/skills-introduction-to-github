using GiMoSLib.Interfaces;
using GiMoSLib.Models;
using GiMoSLib.Core;
using System;

namespace GiMoSLib.Drivers.Leica
{
    /// <summary>Leica total station driver (GeoCOM protocol).</summary>
    public class LeicaTS : TotalStationBase, ITotalStation
    {
        public bool Connect(string port, int baudRate) => Open(port, baudRate);

        public MeasurementResult Measure()
        {
            serial.WriteLine("%R1Q,2008:1,1");
            string response = serial.ReadLine();
            return Parse(response);
        }

        public void Disconnect() => Close();

        private MeasurementResult Parse(string res)
        {
            // GeoCOM response: "%R1P,0,0:0,<Hz_rad>,<V_rad>,<dist>"
            var parts = res.Split(',');
            return new MeasurementResult
            {
                Hz            = RadToDeg(double.Parse(parts[3])),
                V             = RadToDeg(double.Parse(parts[4])),
                SlopeDistance = double.Parse(parts[5]),
                Timestamp     = DateTime.Now,
                Brand         = "Leica"
            };
        }

        private static double RadToDeg(double rad) => rad * (180.0 / Math.PI);
    }
}
