using GiMoSLib.Interfaces;
using GiMoSLib.Models;
using GiMoSLib.Core;
using System;

namespace GiMoSLib.Drivers.Trimble
{
    /// <summary>Trimble total station driver (TAI protocol).</summary>
    public class TrimbleTS : TotalStationBase, ITotalStation
    {
        public bool Connect(string port, int baudRate) => Open(port, baudRate);

        public MeasurementResult Measure()
        {
            serial.WriteLine("?ANGLES");
            string response = serial.ReadLine();
            return Parse(response);
        }

        public void Disconnect() => Close();

        private MeasurementResult Parse(string res)
        {
            // Example: "ANG,045.123456,090.654321,025.1234"
            var parts = res.Split(',');
            return new MeasurementResult
            {
                Hz            = double.Parse(parts[1]),
                V             = double.Parse(parts[2]),
                SlopeDistance = double.Parse(parts[3]),
                Timestamp     = DateTime.Now,
                Brand         = "Trimble"
            };
        }
    }
}
